# Popular mMovies - Project 2
@Udacity Course: Android Developer Nanodegree Program:
https://eu.udacity.com/course/android-developer-nanodegree-by-google--nd801

Simple android application that allows user to select a recipe and see video-guided steps for how to complete it. 

Application uses Exoplayer to display videos, Espresso to test aspects of the UI and ButterKnife library to bind UI elements. 

App has a companion homescreen widget, that displays ingredient list for desired recipe. App functions on tablet devices and phones with appropriate UI.